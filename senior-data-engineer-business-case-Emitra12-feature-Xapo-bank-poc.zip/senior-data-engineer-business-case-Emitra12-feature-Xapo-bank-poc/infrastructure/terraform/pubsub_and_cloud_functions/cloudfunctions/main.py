import requests
import json
import os
from load_dotenv import load_dotenv
from google.cloud import pubsub_v1

# Load environment variables from .env file
load_dotenv()

# Load environment variables from .env
PROJECT_ID = os.getenv("PROJECT_ID")
TOPIC_ID = os.getenv("INPUT_TOPIC")
MEMPOOL_API_URL = os.getenv("MEMPOOL_API_URL")


# Function to fetch and publish mempool data
def fetch_mempool_data(request):
    try:
        response = requests.get(MEMPOOL_API_URL)
        response.raise_for_status()
        data = response.json()
        print(data)

        publisher = pubsub_v1.PublisherClient()
        topic_path = publisher.topic_path(PROJECT_ID, TOPIC_ID)
        publisher.publish(topic_path, json.dumps(data).encode("utf-8"))

        print("Data published successfully.")
    except requests.RequestException as e:
        print(f"Error fetching data: {e}")