import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
import logging
import os
import json
from load_dotenv import load_dotenv
from google.cloud import bigquery

# Load environment variables from .env file
load_dotenv()

# Load environment variables from .env
PROJECT_ID = os.getenv("PROJECT_ID")
PROCESSES_DATASET_ID = os.getenv("PROCESSES_DATASET_ID")
RAW_DATASET_ID = os.getenv("RAW_DATASET_ID")
ERROR_DATASET_ID = os.getenv("ERROR_DATASET_ID")
TABLE_ID = os.getenv("TABLE_ID")
INPUT_TOPIC = os.getenv("INPUT_TOPIC")
RAW_TABLE = os.getenv("RAW_TABLE")
PROCESSED_TABLE = os.getenv("PROCESSED_TABLE")
ERROR_TABLE = os.getenv("ERROR_TABLE")
RUNNER = os.getenv("RUNNER")
STREAMING_FLAG = os.getenv("STREAMING_FLAG")
REGION = os.getenv("REGION")
TEMP_LOCATION = os.getenv("TEMP_LOCATION")
RAW_SCHEMA = os.getenv("RAW_SCHEMA")
INVALID_SCHEMA = os.getenv("INVALID_SCHEMA")

# Enable debug logging for better visibility
logging.basicConfig(level=logging.DEBUG)


class WriteRawToBigQuery(beam.DoFn):
    """Write raw data to BigQuery with ingestion metadata."""

    def process(self, element):
        try:
            # Working with pubsub data , so decode needed
            raw_data_str = element.decode("utf-8")  # Assuming UTF-8 encoding

            raw_data = json.loads(raw_data_str)
            logging.info(f"Decoded raw_data data: {raw_data}")

            # Converting data to Bigquery schema format as string
            raw_data_json = json.dumps(raw_data)

            logging.info(f"Decoded raw_data_json data: {raw_data_json}")
            # Add metadata for ingestion time
            yield {"raw_data": raw_data_json, "ingestion_time": "2024-11-28 21:37:47.646827"}
        except Exception as e:
            logging.error(f"Failed to process raw record: {e}")


class TransformRawToProcessed(beam.DoFn):
    """Transform raw data for the processed BigQuery table with validation."""

    def __init__(self, processed_table_schema):
        self.processed_table_schema = processed_table_schema

    def process(self, element):
        try:
            # Parse the raw JSON string
            raw_json = json.loads(element["raw_data"])
            transformed_record = {}

            # Define prefixes for nested fields
            prefixes = {
                "chain_stats": "chain_",
                "mempool_stats": "mempool_"
            }

            # Loop through the prefixes and dynamically flatten the nested fields
            for key, prefix in prefixes.items():
                nested_fields = raw_json.get(key, {})
                for nested_field, value in nested_fields.items():
                    # Dynamically create the transformed field name
                    transformed_record[f"{prefix}{nested_field}"] = value

            # Add top-level fields (if needed, such as 'address')
            transformed_record["address"] = raw_json.get("address", None)

            # Validate and map fields dynamically
            for field in self.processed_table_schema:
                field_name = field["name"]
                field_type = field["type"]

                value = transformed_record.get(field_name)
                if value is None:
                    raise ValueError(f"Missing required field: {field_name}")

                # Validate data type
                if field_type == "INTEGER" and not isinstance(value, int):
                    raise TypeError(f"Field {field_name} expected INTEGER but got {type(value).__name__}")
                if field_type == "STRING" and not isinstance(value, str):
                    raise TypeError(f"Field {field_name} expected STRING but got {type(value).__name__}")

                transformed_record[field_name] = value

            yield {"status": "success", "record": transformed_record}
        except Exception as e:
            logging.error(f"Failed to transform record: {e}")
            yield {"status": "failure", "record": element, "error": str(e)}


def get_bigquery_table_schema():
    """Fetch the schema of a BigQuery table dynamically."""
    client = bigquery.Client(project=PROJECT_ID)
    table = client.get_table(f"{PROJECT_ID}.{PROCESSES_DATASET_ID}.{TABLE_ID}")
    print(table)
    return [{"name": schema_field.name, "type": schema_field.field_type} for schema_field in table.schema]


def run_pipeline(raw_table, processed_table, error_table, input_topic):
    pipeline_options = PipelineOptions(
        streaming=STREAMING_FLAG,
        # Use "DirectRunner" for local testing without creating dataflow jobs and DataflowRunner for Dataflow jobs
        runner=RUNNER,
        project=PROJECT_ID,
        region=REGION,
        temp_location=TEMP_LOCATION
    )
    pipeline_options.view_as(StandardOptions).streaming = True

    # Fetch the processed table schema dynamically
    processed_table_schema = get_bigquery_table_schema()

    with beam.Pipeline(options=pipeline_options) as p:
        # Step 1: Get the messages from PubSub topic
        messages = p | "Read from Pub/Sub" >> beam.io.ReadFromPubSub(topic=input_topic)

        # Step 2: Process raw data and add metadata
        processed_data = (
                messages
                | "Prepare Raw Data" >> beam.ParDo(WriteRawToBigQuery())
        )

        # Step 3: Write raw data to BigQuery
        failed_inserts = (
                processed_data | "Write Raw Data to BigQuery" >> beam.io.WriteToBigQuery(
            raw_table,
            schema=RAW_SCHEMA,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )
        )

        # Step 4: Validate and transform raw data
        transformed_data = (
                processed_data
                | "Transform Raw Data" >> beam.ParDo(TransformRawToProcessed(processed_table_schema))
        )

        # Step 5: Separate valid and invalid records
        valid_records = (
                transformed_data
                | "Filter Valid Records" >> beam.Filter(lambda x: x["status"] == "success")
                | "Extract Valid Records" >> beam.Map(lambda x: x["record"])
        )

        invalid_records = (
                transformed_data
                | "Filter Invalid Records" >> beam.Filter(lambda x: x["status"] == "failure")
                | "Format Invalid Records" >> beam.Map(lambda x: {
            "raw_data": x["record"]["raw_data"],
            "error": x["error"],
            "ingestion_time": "2024-11-28 21:37:47.646827"
        })
        )

        # Step 6: Write valid records to the processed table
        valid_records | "Write Valid Records to BigQuery" >> beam.io.WriteToBigQuery(
            processed_table,
            schema={"fields": processed_table_schema},
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )

        # Step 7: Write invalid records to the error table
        invalid_records | "Write Invalid Records to BigQuery" >> beam.io.WriteToBigQuery(
            error_table,
            schema=INVALID_SCHEMA,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )


if __name__ == "__main__":

    logging.info("Starting the pipeline...")

    input_topic = INPUT_TOPIC
    raw_table = f"{PROJECT_ID}:{RAW_DATASET_ID}.{RAW_TABLE}"
    processed_table = f"{PROJECT_ID}:{PROCESSES_DATASET_ID}.{PROCESSED_TABLE}"
    error_table = f"{PROJECT_ID}:{ERROR_DATASET_ID}.{ERROR_TABLE}"

    # Run the pipeline
    try:
        run_pipeline(raw_table, processed_table, error_table, input_topic)
    except Exception as e:
        logging.error(f"Pipeline execution failed: {e}")
