# Bitcoin Blockchain Data Pipeline in GCP
<img src="Architecture.png" alt="Project Logo" width="400" height="300"/>


## Overview
This repository contains a Terraform configuration and CI/CD pipeline for deploying a scalable data pipeline that ingests Bitcoin blockchain data into GCP.

## Features
- Real-time ingestion from Mempool.space API.
- Scalable architecture with Pub/Sub, Cloud Functions, and Dataflow.
- Multi-layered data organization using BigQuery.
- Data & schema validations.

# Data Processing Pipeline Architecture

## Assumptions & 
* As we know bitcoin data volume is huge , so I came up with above Architecture.
* I treated this as small POC , so did not follow 100% coding best practice and also because of time constraint.
* I implemented basic validation for POC point of view as there could be many depends on use case.
* I deployed everything from my local system using terraform commands but if we go with CICD then it won't be any issue.
* I could use the Docker here as well but not to go complex setup for POC , so I did not use Docker.

## Overview
This architecture illustrates the end-to-end process of fetching, validating, and storing data from the Mempool API into a scalable data pipeline on Google Cloud Platform (GCP). The pipeline leverages various GCP services to ensure high performance, scalability, and fault tolerance, making it ideal for handling large volumes of real-time data.

## Key Components:
Python Script:

The pipeline starts with a Python script that fetches data from the Mempool API. The script then pushes this data to a GCP Pub/Sub topic for real-time processing.

## GCP Pub/Sub:

Google Cloud Pub/Sub is used as the messaging system that ingests data in real-time. Pub/Sub provides a highly scalable and reliable way to transfer data between services. It allows decoupling between data producers (the Python script) and consumers (Dataflow job), ensuring smooth message handling with automatic retry capabilities.

## Google Cloud Dataflow:

Google Cloud Dataflow is a fully managed stream and batch data processing service that performs the heavy lifting in the pipeline. Dataflow reads data from the Pub/Sub topic, processes it, and applies various transformations, including schema validation.

## Why Dataflow?:
Scalability: Automatically scales to handle massive data volumes.
Fully Managed: No need to manage infrastructure, making it easy to focus on processing logic.
Performance: Optimized for high throughput and low latency, making it suitable for real-time stream processing.

## BigQuery (Raw Layer):

Dataflow inserts the raw data into BigQuery’s raw layer. This layer stores the original data, which can be useful for auditing or reprocessing if needed.

## Why BigQuery?:
Scalability: BigQuery is designed to handle petabytes of data and can scale automatically.
Cost-Effective: Storage in BigQuery is cost-efficient for large volumes of data.
Integration: BigQuery integrates seamlessly with other GCP services and is capable of handling data analytics workloads efficiently.
Schema & DataType Validation:

Once the raw data is inserted into BigQuery, Dataflow performs schema and datatype validation to ensure that the data meets the required structure and type.

## Why Validation?:
Ensuring data integrity is critical for reliable business insights.
Invalid data is routed to the error table to maintain data quality and prevent the downstream systems from being affected by corrupt or malformed data.

## BigQuery (Base Layer Table):

After validation passes, the data is inserted into the base layer table in BigQuery. This table stores the cleaned and validated data for further processing or analysis.

## BigQuery (Error Table):

Any data that fails the validation process is inserted into an error table. This allows for tracking and investigating invalid records, ensuring that no data is lost.

## Business User View:

Finally, a view is created in BigQuery for business users. This view provides them with a clean, aggregated dataset that is ready for querying and analysis, without the complexity of raw data.
Scalability and Performance Considerations

## Pub/Sub

The use of GCP Pub/Sub ensures scalability by allowing the system to ingest high volumes of real-time messages without worrying about performance bottlenecks. Pub/Sub automatically scales as the message volume increases, providing a high throughput messaging system.

## Dataflow

Dataflow offers performance benefits with auto-scaling, so the pipeline can adjust to increased load. By using Apache Beam SDK, Dataflow can efficiently process large datasets, while minimizing latency for real-time streaming.

## BigQuery

BigQuery is highly scalable and designed for handling extremely large datasets, making it perfect for storing the raw and processed data. BigQuery's distributed architecture allows it to scale without manual intervention, ensuring quick query execution even on massive datasets.

## Error Handling
By storing invalid records in a separate error table, we isolate potential issues in the pipeline, making it easy to troubleshoot and maintain high data quality and we can use GCP bucket as well for this purpose.

# Pipeline setup steps or running/deployment steps from local

## Requirements
- Terraform installed.
- GCP account
- GCP project creation
- GCP project with APIs enabled:
  - Cloud Functions
  - BigQuery
  - Pub/Sub
  - Dataflow
  - Cloud scheduler
  - IAM
  - Service account (CICD)
- Cloud Build enabled for CI/CD.
- GCP auth setup in local (CMD Terminal for Winodws)

## Running commands

```sh
Before running the Terraform commands , please run below command to create Data flow templete.
So terraform use Dataflow template to create the job in GCP.

python <Absolute path>\dataflow_pipeline.py 
      --runner DataflowRunner 
      --project <GCP project name>
      --region <GCP region name> 
      --temp_location gs://<Dataflow specific Bucket name>/temp 
      --template_location gs://<Dataflow specific Bucket name>/templates/pubsub_to_bigquery_dataflow_template.json
```

```sh
gcloud config set project <GCP project name>
gcloud auth application-default login

terraform -chdir=infrastructure init -backend-config=<Absolute path>\backend.config

terraform -chdir=infrastructure plan -var-file=<Absolute path>\terraform.tfvars -out=plan.tfplan

terraform -chdir=infrastructure apply plan.tfplan

```